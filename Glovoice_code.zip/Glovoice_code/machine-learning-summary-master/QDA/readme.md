> the is about the algorithm :QDA.
I will often update some codes or theories for QDA 

- the R code for QDA ,2016.10.31