> The introduction for the algorithm KNN,which from my work.

- an example for KNN algorithm. 2016.10.31