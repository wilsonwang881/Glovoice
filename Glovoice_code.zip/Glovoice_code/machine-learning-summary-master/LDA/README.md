> This is about lda algorithms.

- the first update is 2016.10.31,giving a example how to use the LDA.