import csv
with open('capture.csv', 'r') as csvinput:
    with open('data_set_new_2.csv', 'w') as csvoutput:  # change 'a' for append
        writer = csv.writer(csvoutput)
        for row in csv.reader(csvinput):
            if row[0] and row[1] and row[2] and row[3] and row[4] and row[5] and row[6] and row[7] and row[8] and row[9] and row[10] and not row[11] :
                    count = 0
                    for i in range (0,7):
                        if len(str(row[i])) > 3:
                            count = 1
                    if count == 0:
                        writer.writerow(row[0:10]+['0'])  # type here meaning

