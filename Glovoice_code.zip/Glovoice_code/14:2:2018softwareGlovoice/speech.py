from os import system
system('say Hello world!')
