####Author: Libang Liang 2018/3/2#####
import serial
import time
import Client
import csv
import os
from os import system
# -*- coding: utf-8 -*-

#set serial port parameters
serial_speed = 115200
serial_port = '/dev/tty.HC-06-DevB' # bluetooth shield hc-06

#start connection
if __name__ == '__main__':

    file = open("capture.csv","w") #declare csv
    print ("conecting to serial port ...")
    ser = serial.Serial(serial_port, serial_speed, timeout=1)

    print ("recieving message from arduino ...")    
	
    for i in range(200): #record 1000 set of data
        data = ser.readline()
 
        file.write(data.decode("utf-8")) #store data in csv file
        #file.write(",0\n")
        
        #time.sleep(0.05)
	    
    file.close() #close and save csv file
    print(data) #print last set of data
    print ("close connection and start adding meaning")


with open('capture.csv', 'r') as csvinput:
   with open('data_set.csv', 'a') as csvoutput:  # change 'a' for append
        meaning = '7'
        writer = csv.writer(csvoutput)
        for row in csv.reader(csvinput):
            if len(row) == 11:
                if row[0] and row[1] and row[2] and row[3] and row[4] and row[5] and row[6] and row[7] and row[8] and row[9] and row[10]:
                    count = 0
                    for i in range (0,7):
                         if len(str(row[i])) > 3:
                             count = 1
                    if count == 0:
                        writer.writerow(row+[meaning])  # type here meaning
            if len(row) > 11:
                if row[0] and row[1] and row[2] and row[3] and row[4] and row[5] and row[6] and row[7] and row[8] and row[9] and row[10] and not row[11] :
                    count = 0
                    for i in range (0,7):
                        if len(str(row[i])) > 3:
                            count = 1
                    if count == 0:
                        writer.writerow(row+[meaning])  # type here meaning

system('say finish program')
