import csv
with open('capture_copy.csv', 'r') as csvinput:
    with open('data_set.csv', 'a') as csvoutput:
        writer = csv.writer(csvoutput)
        for row in csv.reader(csvinput):
            writer.writerow(row+['0'])  # type here meaning
