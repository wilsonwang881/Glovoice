from data_input_class import data_input
for i in open('database.txt'):
    print (i)

a = data_intput()
a.display_input()
