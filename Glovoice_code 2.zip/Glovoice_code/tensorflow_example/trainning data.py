####Author: Libang Liang 2018/3/2#####
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import os
import urllib.request
import numpy as np
import tensorflow as tf
import shutil

# set data sets directory
TRAINING = "/Users/IvanLeung/Desktop/Glovoice/Glovoice_code/14:2:2018softwareGlovoice/data_set.csv"
TEST = "/Users/IvanLeung/Desktop/Glovoice/Glovoice_code/14:2:2018softwareGlovoice/fuckurselve.csv"

def main():
    # Load datasets.
    # filename: files directory
    # target_dtype: numpy int
    # features_dtype: internal data type is numpy float
    training_set = tf.contrib.learn.datasets.base.load_csv_with_header(
        filename=TRAINING,
        target_dtype=np.int,
        features_dtype=np.float32)
    test_set = tf.contrib.learn.datasets.base.load_csv_with_header(
        filename=TEST,
        target_dtype=np.int,
        features_dtype=np.float32)
   # Specify that all features have real-value data
    feature_columns = [tf.contrib.layers.real_valued_column("", dimension=11)]
   # feature_columns= feature_columns
    # hidden_units = [10，20，10] Build 3 layer DNN with 10, 20, 10 units respectively.
    # n_classes= 3 total number of hand gesture
    # model_dir=/ TMP / iris_model。 TensorFlow will save intermediate points to check data
    classifier = tf.contrib.learn.DNNClassifier(feature_columns=feature_columns,
                                                hidden_units=[10,20,10],
                                                n_classes=3,
                                               model_dir ="/Users/IvanLeung/Desktop/Glovoice/Glovoice_code/tensorflow_example/tmp")
    
    shutil.rmtree("/Users/IvanLeung/Desktop/Glovoice/Glovoice_code/tensorflow_example/tmp")
   
    # Define the training inputs
    def get_train_inputs():
        x = tf.constant(training_set.data)
        y = tf.constant(training_set.target)
        return x, y

   # Fit model.
    classifier.fit(input_fn=get_train_inputs, steps=40000)

   # Define the test inputs
    def get_test_inputs():
            x = tf.constant(test_set.data)
            y = tf.constant(test_set.target)
            return x, y

   # Evaluate accuracy.
    accuracy_score = classifier.evaluate(input_fn=get_test_inputs, steps=1)
    print(accuracy_score)

   # Classify two new flower samples.
    def new_samples():
        return np.array(
            [[323,386,572,402,539,458,494,403,357,390,400]], #should output 0
              dtype=np.float32)
    
    predictions = list(classifier.predict_classes(input_fn=new_samples))

    print(
        "New Samples, Class Predictions:    {}\n"
            .format(predictions))
    print(classifier.get_params(deep=True))

if __name__ == "__main__":
    main()


        







        
