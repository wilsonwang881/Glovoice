from __future__ import absolute_import
from __future__ import division
from __future__ import print_function


import time

import os
import urllib.request

import numpy as np
import tensorflow as tf
import shutil

def main(a):
    feature_columns = [tf.contrib.layers.real_valued_column("", dimension=5)]
    classifier = tf.contrib.learn.DNNClassifier(feature_columns=feature_columns,
                                                hidden_units=[10,20,10],
                                                n_classes=3,
                                               model_dir ="/Users/IvanLeung/Desktop/tensorflow_example/tmp")



    predictions = list(classifier.predict_classes(input_fn=a))

    print(predictions)


if __name__ == "__main__":
    while 1:
        def asdf():
            a = np.array([[479,504,521,350,404]], dtype=np.float32)
            return a

        main(asdf)
        
        time.sleep(1)
    
