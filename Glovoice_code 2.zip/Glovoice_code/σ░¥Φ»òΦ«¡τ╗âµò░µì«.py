import tensorflow as tf
import numpy as np

input_data = np.loadtxt('capture.txt', skiprows=1)
print(input_data)
