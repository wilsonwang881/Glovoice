####Author: Libang Liang 2018/3/2#####
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import serial
import time
import os
import urllib.request
import numpy as np
import tensorflow as tf
import shutil
from os import system #voice production



# -*- coding: utf-8 -*-

word_mapping =   {0: "good",
                                1: "afternoon",
                                2: "everyone"}

# set serial port parameters
serial_speed = 115200
serial_port = '/dev/tty.HC-06-DevB' # bluetooth shield hc-06


def prediction(input_to_model,previous_predictions): #call the trained model
    feature_columns = [tf.contrib.layers.real_valued_column("", dimension=11)]
    classifier = tf.contrib.learn.DNNClassifier(feature_columns=feature_columns,
                                                hidden_units=[10,20,10], # must be the same as trained model
                                                n_classes=3,
                                               model_dir ="/Users/IvanLeung/Desktop/Glovoice/Glovoice_code/tensorflow_example/tmp")
    
    predictions = list(classifier.predict_classes(input_fn=input_to_model))
    if predictions != previous_predictions:
        print(
        "Prediction:    {}\n"
        .format(predictions))
        print(word_mapping[predictions[0]])
        spell = 'say ' +word_mapping[predictions[0]]
        system(spell)
        
    previous_predictions = predictions
   # print(previous_predictions)
    return previous_predictions


if __name__ == '__main__':
    # connect to arduino
    print ("conecting to serial port ...")
    ser = serial.Serial(serial_port, serial_speed, timeout=1)
    print ("recieving message from arduino ...")
    previous_predictions = [5]

	
    while 1: # enter loop of detection
        ser.flushInput()
        data = ser.readline()
        #print(data.decode())
        npdata = np.fromstring(data.decode(),dtype=np.float32,sep=',')

        def input_to_model(): # feed raw data(type string) and reshape to a numpy array
            one = npdata[0]
            two = npdata[1]
            three = npdata[2]
            four = npdata[3]
            five = npdata[4]
            six = npdata[5]
            seven = npdata[6]
            eight = npdata[7]
            nine = npdata[8]
            ten = npdata[9]
            eleven = npdata[10]
            a = np.array([[one,two,three,four,five,six,seven,eight,nine,ten,eleven]], dtype=np.float32)
            return a


        if npdata.size == 11:
            previous_predictions=prediction(input_to_model,previous_predictions)

        time.sleep(0.1) # delay for not printing to much prediction at a time	    

    print ("finish program and close connection!")
