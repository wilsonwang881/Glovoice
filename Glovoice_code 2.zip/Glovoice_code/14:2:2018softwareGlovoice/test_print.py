####Author: Libang Liang 2018/3/2#####
import serial
import time
import Client
# -*- coding: utf-8 -*-

#set serial port parameters
serial_speed = 115200
serial_port = '/dev/tty.HC-06-DevB' # bluetooth shield hc-06

#start connection
if __name__ == '__main__':


    print ("conecting to serial port ...")
    ser = serial.Serial(serial_port, serial_speed, timeout=1)

    print ("recieving message from arduino ...")    
	
    while 1:
        ser.flush()
        data = ser.readline()
        print(data)
        time.sleep(0.1)

    print ("finish program and close connection")
