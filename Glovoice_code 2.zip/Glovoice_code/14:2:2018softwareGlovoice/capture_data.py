


file = open("capture.txt","w")


def write_data_to_txt(data):
    file.write(data)
    
