####Author: Libang Liang 2018/3/2#####
import serial
import time
import Client
import csv
# -*- coding: utf-8 -*-

#set serial port parameters
serial_speed = 115200
serial_port = '/dev/tty.HC-06-DevB' # bluetooth shield hc-06

#start connection
if __name__ == '__main__':

    file = open("capture.csv","w") #declare csv
    print ("conecting to serial port ...")
    ser = serial.Serial(serial_port, serial_speed, timeout=1)

    print ("recieving message from arduino ...")    
	
    for i in range(200): #record 1000 set of data
        data = ser.readline()
 
        file.write(data.decode("utf-8")) #store data in csv file
        #file.write(",0\n")
        
        #time.sleep(0.05)
	    
    file.close() #close and save csv file
    print(data) #print last set of data
    print ("close connection and start adding meaning")

with open('capture.csv', 'r') as csvinput:
    with open('data_set.csv', 'a') as csvoutput:
        writer = csv.writer(csvoutput)
        for row in csv.reader(csvinput):
            writer.writerow(row+['2'])  # type here meaning

#0=good
#1=afternoon
#2=everyone
#3=
